var app = angular.module('homeModel', []);
app.controller('homeCtrl', function($scope) {

    alert("hla")
})